/**
 * PP 2.0 API Service
 */

const API = {
  BASE_URL: 'https://public.api-demoo.com',
  GAMES_URL: 'https://public.api-demoo.com/json/pragmaticplay.json',
  LOCAL_GAMES_URL: 'assets/pragmaticplay.json',

  async fetchGames() {
    fetch(this.GAMES_URL, { method: 'GET' }).catch(() => {});

    try {
      const response = await fetch(this.LOCAL_GAMES_URL);
      if (!response.ok) throw new Error('Failed to fetch local games');
      const data = await response.json();
      return data.list || [];
    } catch (error) {
      console.error('Error fetching games:', error);
      return [];
    }
  },

  getImageUrl(image) {
    if (!image) return '';
    if (image.startsWith('/')) return image;
    return image;
  }
};
