/**
 * Pragmatic Play Games List
 */

const PPGames = {
  container: null,
  games: [],
  filteredGames: [],

  async init() {
    this.container = document.getElementById('games-grid');
    if (!this.container) return;

    this.games = await API.fetchGames();
    this.filteredGames = [...this.games];
    this.render();

    const searchInput = document.querySelector('.search-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => this.search(e.target.value));
    }
  },

  search(query) {
    const q = query.toLowerCase().trim();
    if (!q) {
      this.filteredGames = [...this.games];
    } else {
      this.filteredGames = this.games.filter(game => 
        game.name.toLowerCase().includes(q)
      );
    }
    this.render();
  },

  render() {
    if (!this.container) return;

    const countEl = document.querySelector('.games-count');
    if (countEl) {
      countEl.textContent = `共 ${this.filteredGames.length} 款游戏`;
    }

    if (this.filteredGames.length === 0) {
      this.container.innerHTML = '<div class="games-empty">未找到游戏</div>';
      return;
    }

    this.container.innerHTML = this.filteredGames.map(game => `
      <div class="game-card" data-id="${game.id}">
        <div class="game-image">
          <img src="${API.getImageUrl(game.image)}" alt="${game.name}" loading="lazy">
          <div class="game-overlay">
            <button class="game-btn-play" data-id="${game.id}">试玩</button>
          </div>
        </div>
        <div class="game-name">${game.name}</div>
      </div>
    `).join('');
    this.container.querySelectorAll('.game-btn-play').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const gameId = btn.dataset.id;
        window.location.href = `games.html?id=${gameId}&platform=pp`;
      });
    });

    this.container.querySelectorAll('.game-card').forEach(card => {
      card.addEventListener('click', () => {
        const gameId = card.dataset.id;
        window.location.href = `games.html?id=${gameId}&platform=pp`;
      });
    });
  }
};

document.addEventListener('DOMContentLoaded', () => {
  PPGames.init();
});
