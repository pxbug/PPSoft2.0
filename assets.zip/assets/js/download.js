document.addEventListener('DOMContentLoaded', function() {
  var installBtn = document.querySelector('.bp77-gif');
  var modal = document.getElementById('installModal');

  if (installBtn && modal) {
    installBtn.style.cursor = 'pointer';
    installBtn.addEventListener('click', function() {
      modal.classList.add('active');
    });

    modal.querySelector('.install-close').addEventListener('click', function() {
      modal.classList.remove('active');
    });

    modal.addEventListener('click', function(e) {
      if (e.target === modal) {
        modal.classList.remove('active');
      }
    });
  }
});
