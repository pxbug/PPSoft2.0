(function(){
    var loading=document.getElementById("loading");
    var iframe=document.getElementById("game-frame");
    var params=new URLSearchParams(window.location.search);
    var gameId=params.get("id");
        var platform=(params.get("platform")||"PG").toUpperCase();
    if(!gameId){
        loading.innerHTML='<div class="error-container"><div class="error-title">无效的游戏ID</div><div class="error-desc">请通过正确的游戏入口进入</div><button class="back-button" onclick="window.history.back()">返回首页</button></div>';
        return;
    }
    function showError(title,desc){
        loading.innerHTML='<div class="error-container"><div class="error-title">'+title+'</div><div class="error-desc">'+desc+'</div><button class="retry-button" onclick="window.location.reload()">重试</button><br><button class="back-button" onclick="window.history.back()">返回首页</button></div>';
    }
    var proxyUrl = 'https://public.api-demoo.com/proxy.php?platform=' + platform + '&id=' + gameId;
    iframe.src = proxyUrl;
    iframe.onload = function(){loading.style.display="none";iframe.style.display="block";};
    iframe.onerror = function(){showError("游戏加载失败","请稍后重试或返回首页");};
    document.getElementById("fullscreenBtn").addEventListener("click",function(){
        if(!document.fullscreenEnabled){iframe.classList.add("fullscreen-fake");return;}
        if(iframe.requestFullscreen)iframe.requestFullscreen();
        else if(iframe.webkitRequestFullscreen)iframe.webkitRequestFullscreen();
        else if(iframe.msRequestFullscreen)iframe.msRequestFullscreen();
    });
})();